package Graphics;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

/**
 * Created by davinci on 8/5/16.
 */
public class GUI {

    //JLabels variables
    private static JLabel x;

    //JTextFields variables
    private static JTextField y;

    //JList variables
    private static JList familyListBox;


    private static JScrollPane scrollPane;


    public GUI() {
        JFrame frame = new JFrame("UNICOL - Iventário");
        frame.setSize(2000, 1500);  //resolução da frame
        JPanel painel = new JPanel();
        painel.setLayout(null);

        familyType(painel);

        frame.add(painel); //add painel to the frame
        frame.setDefaultCloseOperation(frame.EXIT_ON_CLOSE); //stop everything when stops the frame
        frame.setResizable(false); //keeping the same windows's size
        frame.setVisible(true); //keep everything visible
    }

    //family type painel
    public static void familyType(JPanel painel){
        //Items do add to the list
        String listData[] = {"PC", "Printer", "Phone", "Cable"};
        //Create the listBox Control
        familyListBox = new JList(listData);
        scrollPane = new JScrollPane(familyListBox);
        scrollPane.setBounds(30, 90, 230, 20);
        //dataList.ensureIndexIsVisible(dataList.getSelectedIndex());
        painel.add(scrollPane);
    }
}
