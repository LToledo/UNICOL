package Model;

/**
 * Created by davinci on 8/8/16.
 */

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


/**
 * This class has the method to connect to database and also has the only connection to this database
 * This class also has contain all methods to do inserts, updates, consults (gets) and deletes on the database
 */
public class ModelFunctions {

    public static Connection con = null;
    public static boolean debug = true;

    //Connection to database to start
    public static void databaseConnetion(){
        //Connection to database
        DatabaseConnection connection = new DatabaseConnection();
        con = connection.databaseConnection();

        if (con == null) {
            System.out.println("CONNECTION REFUSE!!");
        }

        if (debug)
            System.out.println("CONNECTED!! LETS START!!!");
        //Connection to database done!!!

        //DO NOT FORGET TO CLOSE THE DATABASE CONNECTION!!!
    }

    //Add a new location and return true (create and everything is correct) or false (if the supposedly new location already exist)
    public static boolean addnewLocation(String name, String department, String room){
        java.sql.Statement stmt;
        try {
            //First verify if this supposedly new location already exist or not
            String query = "select name, department, room from Location where name like '"+name+"' and department like '"+department+"' and room like '"+room+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query);
            while (result.next()){
                //If enter here, it is because this location already exist, so it does not need to be create again
                return false;
            }
            //otherwise, it needs to be create
            String query2 = "Insert into Location (name,department,room)"+ "values (?,?,?)";
            PreparedStatement preparedStmt= con.prepareStatement(query2);
            preparedStmt.setString(1, name);
            preparedStmt.setString(2, department);
            preparedStmt.setString(3, room);
            if(debug) {
                System.out.println("Insert a new Location!!!");
                System.out.println("Name:" + name);
                System.out.println("Department:" + department);
                System.out.println("room:" + room);
            }
            preparedStmt.execute();
        } catch (SQLException ex) {
            //Logger.getLogger(class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error creating a new location - SQL error!!!");
        }
        return true;
    }

    //Delete a location if this exist, if it does not exist not (true - delete; false - the location to supposedly delete does not exist)
    public static boolean deleteLocation(String name, String department, String room){
        java.sql.Statement stmt;
        try {
            //First verify if this supposedly location already exist or not
            String query = "SELECT  location_id FROM Location WHERE name LIKE '"+name+"' and department LIKE '"+department+"' and room LIKE '"+room+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query);
            System.out.println("test1");
            int id_row = 0;
            if (result.next()){
                System.out.println("test2");
                //If enter here, it is because this location exist, so it will be erased.. for this, we need the id of this row on database
                id_row = Integer.parseInt(result.getString(1));
                String query2 = "DELETE FROM Location WHERE location_id LIKE '"+id_row+"'";
                PreparedStatement preparedStmt= con.prepareStatement(query2);
                preparedStmt.execute();
                System.out.println("test3");
                if(debug) {
                    System.out.println("Delete a Location!!!");
                    System.out.println("Name:" + name);
                    System.out.println("Department:" + department);
                    System.out.println("room:" + room);
                }
            }
            else{
                //If this location does not exist
                if (debug)
                    System.out.println("Does not exist this location!!!");
                return false;
            }

        } catch (SQLException ex) {
            //Logger.getLogger(class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error deleting a especific location - SQL error!!!");
        }
        return true;
    }

    //Add a new product's family
    public static boolean addNewFamily (String name){
        java.sql.Statement stmt;
        try {
            //First verify if this supposedly new family already exist or not
            String query = "select name from Family where name like '"+name+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query);
            while (result.next()){
                //If enter here, it is because this family already exist, so it does not need to be create again
                return false;
            }
            //otherwise, it needs to be create
            String query2 = "Insert into Family (name)"+ "values (?)";
            PreparedStatement preparedStmt= con.prepareStatement(query2);
            preparedStmt.setString(1, name);
            if(debug) {
                System.out.println("Insert a new Location!!!");
                System.out.println("Name:" + name);
            }
            preparedStmt.execute();
        } catch (SQLException ex) {
            //Logger.getLogger(class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error creating a new family - SQL error!!!");
        }
        return true;
    }

    //Delete a family
    public static boolean deleteFamily(String name){
        java.sql.Statement stmt;
        try {
            //First verify if this supposedly family already exist or not
            String query = "SELECT  family_id FROM Family WHERE name LIKE '"+name+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query);
            int id_row = 0;
            if (result.next()){
                //If enter here, it is because this family exist, so it will be erased.. for this, we need the id of this row on database
                id_row = Integer.parseInt(result.getString(1));
                String query2 = "DELETE FROM Family WHERE family_id LIKE '"+id_row+"'";
                PreparedStatement preparedStmt= con.prepareStatement(query2);
                preparedStmt.execute();
                if(debug) {
                    System.out.println("Delete a family!!!");
                    System.out.println("Name:" + name);
                }
            }
            else{
                //If this location does not exist
                if (debug)
                    System.out.println("Does not exist this family!!!");
                return false;
            }

        } catch (SQLException ex) {
            //Logger.getLogger(class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error deleting a especific family - SQL error!!!");
        }
        return true;
    }

    //Add a new product's category
    public static boolean addNewCategory(String name){
        java.sql.Statement stmt;
        try {
            //First verify if this supposedly new category already exist or not
            String query = "select name from Category where name like '"+name+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query);
            while (result.next()){
                //If enter here, it is because this category already exist, so it does not need to be create again
                return false;
            }
            //otherwise, it needs to be create
            String query2 = "Insert into Category (name)"+ "values (?)";
            PreparedStatement preparedStmt= con.prepareStatement(query2);
            preparedStmt.setString(1, name);
            if(debug) {
                System.out.println("Insert a new Category!!!");
                System.out.println("Name:" + name);
            }
            preparedStmt.execute();
        } catch (SQLException ex) {
            //Logger.getLogger(class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error creating a new category - SQL error!!!");
        }
        return true;
    }

    //Delete a category
    public static boolean deleteCategory(String name){
        java.sql.Statement stmt;
        try {
            //First verify if this supposedly category already exist or not
            String query = "SELECT  category_id FROM Category WHERE name LIKE '"+name+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query);
            int id_row = 0;
            if (result.next()){
                //If enter here, it is because this category exist, so it will be erased.. for this, we need the id of this row on database
                id_row = Integer.parseInt(result.getString(1));
                String query2 = "DELETE FROM Category WHERE category_id LIKE '"+id_row+"'";
                PreparedStatement preparedStmt= con.prepareStatement(query2);
                preparedStmt.execute();
                if(debug) {
                    System.out.println("Delete a Category!!!");
                    System.out.println("Name:" + name);
                }
            }
            else{
                //If this location does not exist
                if (debug)
                    System.out.println("Does not exist this category!!!");
                return false;
            }

        } catch (SQLException ex) {
            //Logger.getLogger(class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error deleting a especific category - SQL error!!!");
        }
        return true;
    }


    //Add a date if necessary, because if the date in question already exist, it does not needs to be created again, just return the row's ID
    //Protections like verify the day, month or year.. this is does in the other side, when the user put the inputs!!
    public static int addNewDate(int day, int month, int year){
        java.sql.Statement stmt;
        int id = 0;
        try {
            //First verify if this supposedly new date already exist or not
            String query = "select date_id from Date where day like '"+day+"' AND month like '"+month+"' AND year LIKE '"+year+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query);
            if (result.next()){
                //If enter here, it is because this date already exist, so just need the row's ID
                id = Integer.parseInt(result.getString(1));
            }
            //otherwise, it needs to be create
            else {
                String query2 = "Insert into Date (day, month, year)" + "values (?,?,?)";
                PreparedStatement preparedStmt = con.prepareStatement(query2);
                preparedStmt.setString(1, Integer.toString(day));
                preparedStmt.setString(2, Integer.toString(month));
                preparedStmt.setString(3, Integer.toString(year));
                if (debug) {
                    System.out.println("Insert a new Category!!!");
                    System.out.println("Day:" + day);
                    System.out.println("Month:" + month);
                    System.out.println("Year:" + year);
                }
                preparedStmt.execute();
                //Now, it needs return also the row's ID of the new date to be used after in other method
                stmt = con.createStatement();
                result = stmt.executeQuery(query);
                if (result.next()){
                    //If enter here, it is because this date already exist, so just need the row's ID
                    id = Integer.parseInt(result.getString(1));
                }
            }
        } catch (SQLException ex) {
            //Logger.getLogger(class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error selecting or creating a date - SQL error!!!");
        }
        return id;
    }

    //This method is used just to verify if the suppose new record already exist on the equipments table exactly equal (with the same information in all fields)
    public static boolean verifyNewRecord(String location_name, String location_department, String location_room, String family, String category, int date_day, int date_month, int date_year, String code, String status){
        java.sql.Statement stmt;
        int id_location=0, id_family=0, id_category=0, id_date=0;
        //We need select all ID's that are necessary to do the select after
        try {

            String query_location = "select location_id from Location where name like '"+location_name+"' AND department like '"+location_department+"' AND room LIKE '"+location_room+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query_location);
            if (result.next()){
                id_location = Integer.parseInt(result.getString(1));
            }
        }catch (SQLException ex) {
            //Logger.getLogger(class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error selecting location's ID - SQL error!!!");
        }
        //family's ID
        try {
            String query_family = "select family_id from Family where name like '"+family+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query_family);
            if (result.next()){
                id_family = Integer.parseInt(result.getString(1));
            }
        } catch (SQLException ex) {
            //Logger.getLogger(class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error selecting family's ID - SQL error!!!");
        }
        //Category's ID
        try {
            String query_category = "select category_id from Category where name like '"+category+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query_category);
            if (result.next()){
                id_category = Integer.parseInt(result.getString(1));
            }
        } catch (SQLException ex) {
            System.out.println("Error selecting category's ID - SQL error!!!");
        }
        //Date's ID
        id_date = addNewDate(date_day,date_month,date_year);

        try{
            String query_verification = "SELECT equipments_id from Equipments where id_location like '"+id_location+"' AND id_family like '"+id_family+"' AND id_category like '"+id_category+"' AND id_date like '"+id_date+"' AND code LIKE '"+code+"' AND status LIKE '"+status+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query_verification);
            if (result.next()){
                //if enter here, it is because this record already exist in the table equipments with these same information in all fields (return false if already exist)
                if (debug)
                    System.out.println("This record already exist in the table Equipments with the same information on all fields!!!");
                return true;
            }
            else{
                //Return false if it does not exist yet
                if (debug)
                    System.out.println("This record does not exist yet!!! It is new!!!");
                return false;
            }
        }catch (SQLException ex){
            System.out.println("Error in record verification (all fields) - SQL error!!!");
        }
        return false;
    }

    //Add a new equipment to the inventory (This method just is call after it was call the method called "verifyNewRecord"!!!)
    public static boolean addNewEquipement(String location_name, String location_department, String location_room, String family, String category, int date_day, int date_month, int date_year, String code, String status){
        java.sql.Statement stmt;
        int id_location=0, id_family=0, id_category=0, id_date=0;


        //Get ID's from selected location, family, category and date.. because this ID are created a priori
        //Location's ID - This location can be the same location or a new location
        try {

            String query_location = "select location_id from Location where name like '"+location_name+"' AND department like '"+location_department+"' AND room LIKE '"+location_room+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query_location);
            if (result.next()){
                id_location = Integer.parseInt(result.getString(1));
            }
        } catch (SQLException ex) {
            //Logger.getLogger(class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error selecting location's ID - SQL error!!!");
        }
        //family's ID
        try {
            String query_family = "select family_id from Family where name like '"+family+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query_family);
            if (result.next()){
                id_family = Integer.parseInt(result.getString(1));
            }
        } catch (SQLException ex) {
            //Logger.getLogger(class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error selecting family's ID - SQL error!!!");
        }
        //Category's ID
        try {
            String query_category = "select category_id from Category where name like '"+category+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query_category);
            if (result.next()){
                id_category = Integer.parseInt(result.getString(1));
            }
        } catch (SQLException ex) {
            //Logger.getLogger(class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error selecting category's ID - SQL error!!!");
        }
        //Date's ID
        id_date = addNewDate(date_day,date_month,date_year);

        //Verify if this equipment already exist.. because it is necessary to save the last record at Historic table and then after, update the record in this table
        try{
            String query_verify_equipment = "SELECT equipments_id, id_location, id_date, status FROM Equipments WHERE id_family LIKE '"+id_family+"' AND id_category LIKE '"+id_category+"' AND code LIKE '"+code+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query_verify_equipment);
            //Verify if exist or not this record already.. if YES or else NO
            if(result.next()){
                //Save the record's ID because we will need after
                int record_id = Integer.parseInt(result.getString(1));

                //We need also get the actual location, the date and the status of the record, because this fields can be updated
                String record_location = result.getString(2);
                String record_date = result.getString(3);
                String record_status = result.getString(4);

                //Now we need first save the information about this record on historic table
                String query_save_record = "INSERT INTO Historic (id_location, id_family, id_category, id_date, code, status) VALUES (?,?,?,?,?,?)";
                PreparedStatement preparedStmt = con.prepareStatement(query_save_record);
                preparedStmt.setString(1, record_location); //Here we need to use the last location (the location before update the record)
                preparedStmt.setString(2, Integer.toString(id_family));
                preparedStmt.setString(3, Integer.toString(id_category));
                preparedStmt.setString(4, record_date); //Here we need to use the last date (the date before update the record)
                preparedStmt.setString(5, code);
                preparedStmt.setString(6, record_status); //Here we need to use the last status (the equipment's status before update the record)
                preparedStmt.execute();

                //After we need update the record at Equipments table
                String query_updateRecord = "UPDATE Equipments SET id_location=?, id_family=?, id_category=?, id_date=?, code=?, status=? WHERE equipments_id=?";
                preparedStmt = con.prepareStatement(query_updateRecord);
                preparedStmt.setString(1, Integer.toString(id_location));
                preparedStmt.setString(2, Integer.toString(id_family));
                preparedStmt.setString(3, Integer.toString(id_category));
                preparedStmt.setString(4, Integer.toString(id_date));
                preparedStmt.setString(5, code);
                preparedStmt.setString(6, status);
                preparedStmt.setString(7, Integer.toString(record_id));
                preparedStmt.execute();
            }
            //if not, we just need to create a new record at Equipments table with these information
            else{
                String query_insertNewEquipmentRecord = "INSERT INTO Equipments (id_location, id_family, id_category, id_date, code, status) VALUES (?,?,?,?,?,?)";
                PreparedStatement preparedStatement = con.prepareStatement(query_insertNewEquipmentRecord);
                preparedStatement.setString(1, Integer.toString(id_location));
                preparedStatement.setString(2, Integer.toString(id_family));
                preparedStatement.setString(3, Integer.toString(id_category));
                preparedStatement.setString(4, Integer.toString(id_date));
                preparedStatement.setString(5, code);
                preparedStatement.setString(6, status);
                preparedStatement.execute();
            }
        } catch (SQLException ex) {
            //Logger.getLogger(class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error creating or update a new equipment record - SQL error!!!");
            return false;
        }
        return true;
    }
}
