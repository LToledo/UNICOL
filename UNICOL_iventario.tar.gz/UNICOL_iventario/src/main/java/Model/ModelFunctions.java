package Model;

/**
 * Created by davinci on 8/8/16.
 */

import com.sun.org.apache.bcel.internal.generic.IF_ACMPEQ;
import com.sun.org.apache.bcel.internal.generic.INEG;
import org.w3c.dom.ls.LSInput;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * This class has the method to connect to database and also has the only connection to this database
 * This class also has contain all methods to do inserts, updates, consults (gets) and deletes on the database
 */
public class ModelFunctions {

    public static Connection con = null;
    public static boolean debug = true;

    //Connection to database to start
    public static void databaseConnetion(){
        //Connection to database
        DatabaseConnection connection = new DatabaseConnection();
        con = connection.databaseConnection();

        if (con == null) {
            System.out.println("CONNECTION REFUSE!!");
        }

        if (debug)
            System.out.println("CONNECTED!! LETS START!!!");
        //Connection to database done!!!

        //DO NOT FORGET TO CLOSE THE DATABASE CONNECTION!!!
    }

    //Add a new location and return true (create and everything is correct) or false (if the supposedly new location already exist)
    public static boolean addnewLocation(String name, String department, String room){
        java.sql.Statement stmt;
        try {
            //First verify if this supposedly new location already exist or not
            String query = "select name, department, room from Location where name like '"+name+"' and department like '"+department+"' and room like '"+room+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query);
            while (result.next()){
                //If enter here, it is because this location already exist, so it does not need to be create again
                return false;
            }
            //otherwise, it needs to be create
            String query2 = "Insert into Location (name,department,room)"+ "values (?,?,?)";
            PreparedStatement preparedStmt= con.prepareStatement(query2);
            preparedStmt.setString(1, name);
            preparedStmt.setString(2, department);
            preparedStmt.setString(3, room);
            if(debug) {
                System.out.println("Insert a new Location!!!");
                System.out.println("Name:" + name);
                System.out.println("Department:" + department);
                System.out.println("room:" + room);
            }
            preparedStmt.execute();
        } catch (SQLException ex) {
            //Logger.getLogger(class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error creating a new location - SQL error!!!");
        }
        return true;
    }

    //Delete a location if this exist, if it does not exist not (true - delete; false - the location to supposedly delete does not exist)
    public static boolean deleteLocation(String name, String department, String room){
        java.sql.Statement stmt;
        try {
            //First verify if this supposedly location already exist or not
            String query = "SELECT  location_id FROM Location WHERE name LIKE '"+name+"' and department LIKE '"+department+"' and room LIKE '"+room+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query);
            System.out.println("test1");
            int id_row = 0;
            if (result.next()){
                System.out.println("test2");
                //If enter here, it is because this location exist, so it will be erased.. for this, we need the id of this row on database
                id_row = Integer.parseInt(result.getString(1));
                String query2 = "DELETE FROM Location WHERE location_id LIKE '"+id_row+"'";
                PreparedStatement preparedStmt= con.prepareStatement(query2);
                preparedStmt.execute();
                System.out.println("test3");
                if(debug) {
                    System.out.println("Delete a Location!!!");
                    System.out.println("Name:" + name);
                    System.out.println("Department:" + department);
                    System.out.println("room:" + room);
                }
            }
            else{
                //If this location does not exist
                if (debug)
                    System.out.println("Does not exist this location!!!");
                return false;
            }

        } catch (SQLException ex) {
            //Logger.getLogger(class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error deleting a especific location - SQL error!!!");
        }
        return true;
    }

    //Add a new product's family
    public static boolean addNewFamily (String name){
        java.sql.Statement stmt;
        try {
            //First verify if this supposedly new family already exist or not
            String query = "select name from Family where name like '"+name+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query);
            while (result.next()){
                //If enter here, it is because this family already exist, so it does not need to be create again
                return false;
            }
            //otherwise, it needs to be create
            String query2 = "Insert into Family (name)"+ "values (?)";
            PreparedStatement preparedStmt= con.prepareStatement(query2);
            preparedStmt.setString(1, name);
            if(debug) {
                System.out.println("Insert a new Location!!!");
                System.out.println("Name:" + name);
            }
            preparedStmt.execute();
        } catch (SQLException ex) {
            //Logger.getLogger(class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error creating a new family - SQL error!!!");
        }
        return true;
    }

    //Delete a family
    public static boolean deleteFamily(String name){
        java.sql.Statement stmt;
        try {
            //First verify if this supposedly family already exist or not
            String query = "SELECT  family_id FROM Family WHERE name LIKE '"+name+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query);
            int id_row = 0;
            if (result.next()){
                //If enter here, it is because this family exist, so it will be erased.. for this, we need the id of this row on database
                id_row = Integer.parseInt(result.getString(1));
                String query2 = "DELETE FROM Family WHERE family_id LIKE '"+id_row+"'";
                PreparedStatement preparedStmt= con.prepareStatement(query2);
                preparedStmt.execute();
                if(debug) {
                    System.out.println("Delete a family!!!");
                    System.out.println("Name:" + name);
                }
            }
            else{
                //If this location does not exist
                if (debug)
                    System.out.println("Does not exist this family!!!");
                return false;
            }

        } catch (SQLException ex) {
            //Logger.getLogger(class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error deleting a especific family - SQL error!!!");
        }
        return true;
    }

    //Add a new product's category
    public static boolean addNewCategory(String name){
        java.sql.Statement stmt;
        try {
            //First verify if this supposedly new category already exist or not
            String query = "select name from Category where name like '"+name+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query);
            while (result.next()){
                //If enter here, it is because this category already exist, so it does not need to be create again
                return false;
            }
            //otherwise, it needs to be create
            String query2 = "Insert into Category (name)"+ "values (?)";
            PreparedStatement preparedStmt= con.prepareStatement(query2);
            preparedStmt.setString(1, name);
            if(debug) {
                System.out.println("Insert a new Category!!!");
                System.out.println("Name:" + name);
            }
            preparedStmt.execute();
        } catch (SQLException ex) {
            //Logger.getLogger(class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error creating a new category - SQL error!!!");
        }
        return true;
    }

    //Delete a category
    public static boolean deleteCategory(String name){
        java.sql.Statement stmt;
        try {
            //First verify if this supposedly category already exist or not
            String query = "SELECT  category_id FROM Category WHERE name LIKE '"+name+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query);
            int id_row = 0;
            if (result.next()){
                //If enter here, it is because this category exist, so it will be erased.. for this, we need the id of this row on database
                id_row = Integer.parseInt(result.getString(1));
                String query2 = "DELETE FROM Category WHERE category_id LIKE '"+id_row+"'";
                PreparedStatement preparedStmt= con.prepareStatement(query2);
                preparedStmt.execute();
                if(debug) {
                    System.out.println("Delete a Category!!!");
                    System.out.println("Name:" + name);
                }
            }
            else{
                //If this location does not exist
                if (debug)
                    System.out.println("Does not exist this category!!!");
                return false;
            }

        } catch (SQLException ex) {
            //Logger.getLogger(class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error deleting a especific category - SQL error!!!");
        }
        return true;
    }


    //Add a date if necessary, because if the date in question already exist, it does not needs to be created again, just return the row's ID
    //Protections like verify the day, month or year.. this is does in the other side, when the user put the inputs!!
    public static int addNewDate(int day, int month, int year){
        java.sql.Statement stmt;
        int id = 0;
        try {
            //First verify if this supposedly new date already exist or not
            String query = "select date_id from Date where day like '"+day+"' AND month like '"+month+"' AND year LIKE '"+year+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query);
            if (result.next()){
                //If enter here, it is because this date already exist, so just need the row's ID
                id = Integer.parseInt(result.getString(1));
            }
            //otherwise, it needs to be create
            else {
                String query2 = "Insert into Date (day, month, year)" + "values (?,?,?)";
                PreparedStatement preparedStmt = con.prepareStatement(query2);
                preparedStmt.setString(1, Integer.toString(day));
                preparedStmt.setString(2, Integer.toString(month));
                preparedStmt.setString(3, Integer.toString(year));
                if (debug) {
                    System.out.println("Insert a new Category!!!");
                    System.out.println("Day:" + day);
                    System.out.println("Month:" + month);
                    System.out.println("Year:" + year);
                }
                preparedStmt.execute();
                //Now, it needs return also the row's ID of the new date to be used after in other method
                stmt = con.createStatement();
                result = stmt.executeQuery(query);
                if (result.next()){
                    //If enter here, it is because this date already exist, so just need the row's ID
                    id = Integer.parseInt(result.getString(1));
                }
            }
        } catch (SQLException ex) {
            //Logger.getLogger(class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error selecting or creating a date - SQL error!!!");
        }
        return id;
    }

    //This method is used just to verify if the suppose new record already exist on the equipments table exactly equal (with the same information in all fields)
    public static boolean verifyNewRecord(String location_name, String location_department, String location_room, String family, String category, int date_day, int date_month, int date_year, String code, String status){
        java.sql.Statement stmt;
        int id_location=0, id_family=0, id_category=0, id_date=0;
        //We need select all ID's that are necessary to do the select after
        try {

            String query_location = "select location_id from Location where name like '"+location_name+"' AND department like '"+location_department+"' AND room LIKE '"+location_room+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query_location);
            if (result.next()){
                id_location = Integer.parseInt(result.getString(1));
            }
        }catch (SQLException ex) {
            //Logger.getLogger(class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error selecting location's ID - SQL error!!!");
        }
        //family's ID
        try {
            String query_family = "select family_id from Family where name like '"+family+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query_family);
            if (result.next()){
                id_family = Integer.parseInt(result.getString(1));
            }
        } catch (SQLException ex) {
            //Logger.getLogger(class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error selecting family's ID - SQL error!!!");
        }
        //Category's ID
        try {
            String query_category = "select category_id from Category where name like '"+category+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query_category);
            if (result.next()){
                id_category = Integer.parseInt(result.getString(1));
            }
        } catch (SQLException ex) {
            System.out.println("Error selecting category's ID - SQL error!!!");
        }
        //Date's ID
        id_date = addNewDate(date_day,date_month,date_year);

        try{
            String query_verification = "SELECT equipments_id from Equipments where id_location like '"+id_location+"' AND id_family like '"+id_family+"' AND id_category like '"+id_category+"' AND id_date like '"+id_date+"' AND code LIKE '"+code+"' AND status LIKE '"+status+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query_verification);
            if (result.next()){
                //if enter here, it is because this record already exist in the table equipments with these same information in all fields (return false if already exist)
                if (debug)
                    System.out.println("This record already exist in the table Equipments with the same information on all fields!!!");
                return true;
            }
            else{
                //Return false if it does not exist yet
                if (debug)
                    System.out.println("This record does not exist yet!!! It is new!!!");
                return false;
            }
        }catch (SQLException ex){
            System.out.println("Error in record verification (all fields) - SQL error!!!");
        }
        return false;
    }

    //Add a new equipment to the inventory (This method just is call after it was call the method called "verifyNewRecord"!!!)
    public static boolean addNewEquipement(String location_name, String location_department, String location_room, String family, String category, int date_day, int date_month, int date_year, String code, String status){
        java.sql.Statement stmt;
        int id_location=0, id_family=0, id_category=0, id_date=0;


        //Get ID's from selected location, family, category and date.. because this ID are created a priori
        //Location's ID - This location can be the same location or a new location
        try {
            String query_location = "select location_id from Location where name like '"+location_name+"' AND department like '"+location_department+"' AND room LIKE '"+location_room+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query_location);
            if (result.next()){
                id_location = Integer.parseInt(result.getString(1));
            }
        } catch (SQLException ex) {
            //Logger.getLogger(class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error selecting location's ID - SQL error!!!");
        }
        //family's ID
        try {
            String query_family = "select family_id from Family where name like '"+family+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query_family);
            if (result.next()){
                id_family = Integer.parseInt(result.getString(1));
            }
        } catch (SQLException ex) {
            //Logger.getLogger(class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error selecting family's ID - SQL error!!!");
        }
        //Category's ID
        try {
            String query_category = "select category_id from Category where name like '"+category+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query_category);
            if (result.next()){
                id_category = Integer.parseInt(result.getString(1));
            }
        } catch (SQLException ex) {
            //Logger.getLogger(class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error selecting category's ID - SQL error!!!");
        }
        //Date's ID
        id_date = addNewDate(date_day,date_month,date_year);

        //Verify if this equipment already exist.. because it is necessary to save the last record at Historic table and then after, update the record in this table
        try{
            String query_verify_equipment = "SELECT equipments_id, id_location, id_date, status FROM Equipments WHERE id_family LIKE '"+id_family+"' AND id_category LIKE '"+id_category+"' AND code LIKE '"+code+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query_verify_equipment);
            //Verify if exist or not this record already.. if YES or else NO
            if(result.next()){
                //Save the record's ID because we will need after
                int record_id = Integer.parseInt(result.getString(1));

                //We need also get the actual location, the date and the status of the record, because this fields can be updated
                String record_location = result.getString(2);
                String record_date = result.getString(3);
                String record_status = result.getString(4);

                //Now we need first save the information about this record on historic table
                String query_save_record = "INSERT INTO Historic (id_location, id_family, id_category, id_date, code, status) VALUES (?,?,?,?,?,?)";
                PreparedStatement preparedStmt = con.prepareStatement(query_save_record);
                preparedStmt.setString(1, record_location); //Here we need to use the last location (the location before update the record)
                preparedStmt.setString(2, Integer.toString(id_family));
                preparedStmt.setString(3, Integer.toString(id_category));
                preparedStmt.setString(4, record_date); //Here we need to use the last date (the date before update the record)
                preparedStmt.setString(5, code);
                preparedStmt.setString(6, record_status); //Here we need to use the last status (the equipment's status before update the record)
                preparedStmt.execute();

                //After we need update the record at Equipments table
                String query_updateRecord = "UPDATE Equipments SET id_location=?, id_family=?, id_category=?, id_date=?, code=?, status=? WHERE equipments_id=?";
                preparedStmt = con.prepareStatement(query_updateRecord);
                preparedStmt.setString(1, Integer.toString(id_location));
                preparedStmt.setString(2, Integer.toString(id_family));
                preparedStmt.setString(3, Integer.toString(id_category));
                preparedStmt.setString(4, Integer.toString(id_date));
                preparedStmt.setString(5, code);
                preparedStmt.setString(6, status);
                preparedStmt.setString(7, Integer.toString(record_id));
                preparedStmt.execute();
            }
            //if not, we just need to create a new record at Equipments table with these information
            else{
                String query_insertNewEquipmentRecord = "INSERT INTO Equipments (id_location, id_family, id_category, id_date, code, status) VALUES (?,?,?,?,?,?)";
                PreparedStatement preparedStatement = con.prepareStatement(query_insertNewEquipmentRecord);
                preparedStatement.setString(1, Integer.toString(id_location));
                preparedStatement.setString(2, Integer.toString(id_family));
                preparedStatement.setString(3, Integer.toString(id_category));
                preparedStatement.setString(4, Integer.toString(id_date));
                preparedStatement.setString(5, code);
                preparedStatement.setString(6, status);
                preparedStatement.execute();
            }
        } catch (SQLException ex) {
            //Logger.getLogger(class.getName()).log(Level.SEVERE, null, ex);
            System.out.println("Error creating or update a new equipment record - SQL error!!!");
            return false;
        }
        return true;
    }

    //Method to get all locations from the table Location
    public static boolean allLocations(ArrayList locations_list){
        java.sql.Statement stmt;
        try{
            String query = "SELECT name, department, room FROM Location";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query);
            while (result.next()){
                //Each record is a hashmap because after it is better for us separate each field from each row
                Map aux = new HashMap();
                aux.put("name", result.getString(1));
                aux.put("department", result.getString(2));
                aux.put("room", result.getString(3));
                locations_list.add(aux);
            }
        }catch (SQLException ex){
            System.out.println("Error selecting all Locations - SQL error!!!");
            return false;
        }
        return true;
    }


    //Method to get all families from the table Family
    public static List<String> allFamily(){
        List<String> families_list = new ArrayList<String>();
        java.sql.Statement stmt;
        try{
            String query = "SELECT name FROM Family";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query);
            while (result.next()){
                //Save each row selected
                families_list.add(result.getString(1));
            }
        }catch (SQLException ex){
            System.out.println("Error selecting all Families - SQL error!!!");
        }
        return families_list;
    }

    //Method to get all categories from the table Category
    public static List<String> allCategories(){
        List<String> categories_list = new ArrayList<String>();
        java.sql.Statement stmt;
        try{
            String query = "SELECT name FROM Category";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query);
            while (result.next()){
                //Save each row selected
                categories_list.add(result.getString(1));
            }
        }catch (SQLException ex){
            System.out.println("Error selecting all Categories - SQL error!!!");
        }
        return categories_list;
    }

    //Method to get a specific location's ID (default - 0)
    public static int getSpecificLocationID(String name, String department, String room){
        java.sql.Statement stmt;
        int location_id = 0;
        try{
            String query = "SELECT location_id FROM Location WHERE name LIKE '"+name+"' AND department LIKE '"+department+"' AND room LIKE '"+room+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query);
            //If exist this specific location
            if (result.next()){
                location_id = Integer.parseInt(result.getString(1));
            }
        }catch (SQLException ex){
            System.out.println("Error getting a specific locacion's ID - SQL error!!!");
        }
        return location_id;
    }

    //Method to get a specific family's ID (default - 0)
    public static int getSpecificFamilyID(String name){
        java.sql.Statement stmt;
        int family_id = 0;
        try{
            String query = "SELECT family_id FROM Family WHERE name LIKE '"+name+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query);
            //If exist this specific family
            if (result.next()){
                family_id = Integer.parseInt(result.getString(1));
            }
        }catch (SQLException ex){
            System.out.println("Error selecting a specific family's ID - SQL error!!!");
        }
        return family_id;
    }

    //Method to get a specific category (default - 0)
    public static int getSpecificCategoryID(String name){
        java.sql.Statement stmt;
        int category_id = 0;
        try{
            String query = "SELECT category_id FROM Category WHERE name LIKE '"+name+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query);
            //If this specific category exist
            if (result.next()){
                category_id = Integer.parseInt(result.getString(1));
            }
        }catch (SQLException ex){
            System.out.println("Error getting a specific category's ID - SQL error!!!");
        }
        return category_id;
    }

    //Method to get the information about a specific location
    public static String[] getLocationInformation(int locationID){
        java.sql.Statement stmt;
        String  []locationInformation = new String[3];
        String query_locationInformation = "SELECT name, department, room FROM Location where location_id LIKE '"+locationID+"'";
        try {
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query_locationInformation);
            if (result.next()) {
                locationInformation[0] = result.getString(1);
                locationInformation[1] = result.getString(2);
                locationInformation[2] = result.getString(3);
            }
        }catch (SQLException ex){
            System.out.println("Error getting all information about a specific location - SQL error!!!");
        }
        return locationInformation;
    }

    //Method to get the name of a specific family
    public static String getFamilyName(int id){
        java.sql.Statement stmt;
        String familyName = "";
        try{
            String query = "SELECT name FROM Family WHERE family_id LIKE '"+id+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query);
            if (result.next()){
                familyName = result.getString(1);
            }
        }catch (SQLException ex){
            System.out.println("Error getting the name of a specific family - SQL error!!!");
        }
        return familyName;
    }

    //Method to get the name of a specific category
    public static String getCategoryName(int id){
        java.sql.Statement stmt;
        String categoryName = "";
        try{
            String query = "";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query);
            if (result.next()){
                categoryName = result.getString(1);
            }
        }catch (SQLException ex){
            System.out.println("Error getting the name of a specific category _ SQL error!!!");
        }
        return categoryName;
    }

    //Method to get all information about a specific date
    public static Integer[] getDateInformation(int dateID){
        java.sql.Statement stmt;
        Integer []dateInformation = new Integer[3];
        try{
            String query = "SELECT day, month, year FROM Date WHERE day LIKE '"+dateID+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query);
            if (result.next()){
                dateInformation[0] = Integer.parseInt(result.getString(1)); //day
                dateInformation[1] = Integer.parseInt(result.getString(2)); //month
                dateInformation[2] = Integer.parseInt(result.getString(3)); //year
            }
        }catch (SQLException ex){
            System.out.println("Error getting information about a specific date - SQL error!!!");
        }
        return dateInformation;
    }


    //Method to get information about a specific equipment (from Equipments tables or Historic table)
    public static boolean getSpecificEquipment(ArrayList specific_equipment, int family_id, int category_id, String code, String tableName){
        java.sql.Statement stmt;
        int locationID = 0, dateID = 0;
        String status = "", family = "", category = "";
        String []locationInformation = new String[3];
        Integer []dateInformation = new Integer[3];
        String data_day = "", data_month = "", data_year = "";
        try{
            String query_equipment = "SELECT id_location, id_date, status FROM "+tableName+" WHERE id_family LIKE '"+family_id+"' AND id_category LIKE '"+category_id+"' AND code LIKE '"+code+"'";
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query_equipment);
            //As exist just one record of each equipment at table equipments, this query just will return one row, if this equipment exist of course, otherwise return nothing
            if (result.next()){
                //Save some information about last query that it will be needed after
                locationID = Integer.parseInt(result.getString(1));
                dateID = Integer.parseInt(result.getString(2));
                //Status information
                status = result.getString(3);

                //Get the information about the location of this equipment
                locationInformation = getLocationInformation(locationID); //(0 - name, 1 - department, 2 - room)
                //Get the information about the family
                family = getFamilyName(family_id);
                //Get the information about the category
                category = getCategoryName(category_id);
                //Get the information about the date
                dateInformation = getDateInformation(dateID); //(0 - day, 1  - month, 2 - year)

                //Now, we have all information to build a map with all information about this specific equipment
                Map equipmentInformation = new HashMap();
                equipmentInformation.put("LocationName", locationInformation[0]);
                equipmentInformation.put("LocationDepartment", locationInformation[1]);
                equipmentInformation.put("LocationRoom", locationInformation[2]);
                equipmentInformation.put("Family", family);
                equipmentInformation.put("Category", category);
                equipmentInformation.put("DateDay", dateInformation[0]);
                equipmentInformation.put("DateMonth", dateInformation[1]);
                equipmentInformation.put("DateYear", dateInformation[2]);
                equipmentInformation.put("Code", code);
                equipmentInformation.put("Status", status);
                //Add this map to the ArrayList
                specific_equipment.add(equipmentInformation);
            }
        }catch (SQLException ex){
            System.out.println("Error getting a specif equipment - SQL error!!!");
        }
        return true;
    }

    //Method to get all equipments from the Equipment table
    public static boolean getAllEquipmentsInformation(ArrayList allEquipmentsInformation){
        java.sql.Statement stmt;
        String family, category, code;
        //First it needs select all familyID, categoryID and code to after it can be used through the method getSpecificEquipment
        try{
            String query = "SELECT id_family, id_category, code FROM Equipments ORDER BY id_family, id_category"; //order by family and after by category
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query);
            while (result.next()){
                family = result.getString(1);
                category = result.getString(2);
                code = result.getString(3);
                //Call the method getSpecificEquipment to get all information about one equipment and it will does this until has more equipments
                getSpecificEquipment(allEquipmentsInformation, Integer.parseInt(family), Integer.parseInt(category), code, "Equipments");
            }
        }catch (SQLException ex){
            System.out.println("Error getting familyID, categoryID and code at getAllEquipmentsInformation method - SQL error");
        }
        return true;
    }

    //Method to get all equipments information from the Historic table
    public static boolean getAllEquipmentsInformationHistoric(ArrayList allEquipmentsInformationHistoric){
        java.sql.Statement stmt;
        String family, category, code;
        //First it needs select all familyID, categoryID and code to after it can be used through the method getSpecificEquipment
        try{
            String query = "SELECT id_family, id_category, code FROM Equipments ORDER BY id_family, id_category"; //order by family and after by category
            stmt = con.createStatement();
            ResultSet result = stmt.executeQuery(query);
            while (result.next()){
                family = result.getString(1);
                category = result.getString(2);
                code = result.getString(3);
                //Call the method getSpecificEquipment to get all information about one equipment and it will does this until has more equipments
                getSpecificEquipment(allEquipmentsInformationHistoric, Integer.parseInt(family), Integer.parseInt(category), code, "Historic");
            }
        }catch (SQLException ex){
            System.out.println("Error getting familyID, categoryID and code at getAllEquipmentsInformation method - SQL error");
        }
        return true;
    }

}
